package com.example.kosu.dataType;

enum Color {
    BLACK,
    WHITE
}
