package com.example.kosu.dataType;

public class Sneakers {
    private String pathToImage;
    private String name;
    private String price;
    private Integer size;
    private String colorLace;
    private Color color;

    private String textLeftInside;
    private String textLeftExternal;

    private String textRightInside;
    private String textRightExternal;

}
